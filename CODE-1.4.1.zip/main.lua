ANCHO_VENTANA = 800
ANCHO_JUGADOR = 150
TAM_PAYASO = 72
JUGADOR_Y = 530
JUGADOR_VELOCITY = 15
LANGTEXTS = require("objectsgame.LANG")


TEXT_GAME_NAME = LANGTEXTS.GameNameText
TEXT_MENU_SELECT_INPUT = LANGTEXTS.GameInputText
TEXT_MENU_END = LANGTEXTS.GameEnd


function love.load()
	love.window.setTitle("Lluvia de beats")
	img_jugador = love.graphics.newImage("textures/player.png")
	img_payaso = love.graphics.newImage("textures/beat.png")
	img_payaso2 = love.graphics.newImage("textures/beat2.png")
	img_background = love.graphics.newImage("textures/background.png")

	jugador_x = ANCHO_VENTANA / 2 - ANCHO_JUGADOR / 2

	payaso_x = love.math.random(0, ANCHO_VENTANA - TAM_PAYASO)
	payaso_y = 0
	payaso_x2 = love.math.random(0, ANCHO_VENTANA - TAM_PAYASO)
	payaso_y2 = 0

	puntos = 0
	multiplicador = 0 
	multiplicador2 = 0 
	estado = "inicio"
end

function love.update()
	if estado == "inicio" then
		if love.keyboard.isDown("t") then
			entrada = "teclado"
			estado = "juego"
		elseif love.keyboard.isDown("m") then
			entrada = "mouse"
			estado = "juego"
		end
	elseif estado == "juego" then
		payaso_y = payaso_y + (4 + multiplicador)
		payaso_y2 = payaso_y2 + (1.5 + multiplicador2)
		if payaso_y + TAM_PAYASO >= JUGADOR_Y + 45 and payaso_y <= JUGADOR_Y + 72 and payaso_x + TAM_PAYASO >= jugador_x and payaso_x <= jugador_x + ANCHO_JUGADOR then

			payaso_x = love.math.random(0, ANCHO_VENTANA - TAM_PAYASO)
			payaso_y = -TAM_PAYASO

			puntos = puntos + 1
			multiplicador = puntos / 3
		elseif payaso_y >= 600 then
			estado = "fin_juego"
		end
		if payaso_y2 + TAM_PAYASO >= JUGADOR_Y + 45 and payaso_y2 <= JUGADOR_Y + 72 and payaso_x2 + TAM_PAYASO >= jugador_x and payaso_x2 <= jugador_x + ANCHO_JUGADOR then

			payaso_x2 = love.math.random(0, ANCHO_VENTANA - TAM_PAYASO)
			payaso_y2 = -TAM_PAYASO

			puntos = puntos + 1
			multiplicador2 = puntos / 1.5
		elseif payaso_y2 >= 600 then
			estado = "fin_juego"
		end
		if entrada == "mouse" then
			jugador_x = love.mouse.getX()
		else
			if love.keyboard.isDown('left') then
				jugador_x = jugador_x - JUGADOR_VELOCITY
			elseif love.keyboard.isDown('right') then
				jugador_x = jugador_x + JUGADOR_VELOCITY
			end
			if jugador_x < 0 then
				jugador_x = 0

			elseif jugador_x > ANCHO_VENTANA - ANCHO_JUGADOR then
				jugador_x = ANCHO_VENTANA - ANCHO_JUGADOR
			end
		end
	end
end

function love.draw()
	print("Drawing...")
	love.graphics.draw(img_background, 0 , 0)
	if estado == "inicio" then
		love.graphics.printf(TEXT_GAME_NAME, 0, 100, ANCHO_VENTANA,
								"center")
		love.graphics.printf("V 1.4", 0, 500, ANCHO_VENTANA,
								"center")
		love.graphics.printf(TEXT_MENU_SELECT_INPUT,
							0, 300, ANCHO_VENTANA,"center")
	elseif estado == "juego" then
		--en juego
		love.graphics.draw(img_jugador, jugador_x, JUGADOR_Y)
		love.graphics.draw(img_payaso, payaso_x, payaso_y)
		love.graphics.draw(img_payaso2, payaso_x2, payaso_y2)
		love.graphics.print("Puntos: ", 0, 0)
		love.graphics.print(puntos, 80, 0)
	else
		--La partida terminada
		love.graphics.printf(TEXT_MENU_END, 0, 200, ANCHO_VENTANA,
								"center")
		love.graphics.printf("Puntos: "..puntos, 0, 300, ANCHO_VENTANA,
								"center")
	end
end
