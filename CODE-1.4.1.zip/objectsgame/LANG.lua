local LANG = {}

LANG.GameNameText = "RAIN OF BEATS"
LANG.GameInputText = "Presione T para jugar con teclado, M para jugar con mouse"
LANG.GameEnd = "Fin del juego"

return LANG